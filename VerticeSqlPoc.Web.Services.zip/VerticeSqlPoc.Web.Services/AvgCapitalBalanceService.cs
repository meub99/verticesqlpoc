﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using VerticeSqlPoc.Web.Services.Interfaces;
using VerticeSqlPoc.Web.Services.Models;

namespace VerticeSqlPoc.Web.Services
{
    public class AvgCapitalBalanceService : IAvgCapitalBalanceService
    {
        //public ClientResponse Calculate(ref decimal[,] cacheDecimal, ref string[,] cacheString, ref string[,] cacheDate, int startRow, int endRow)
        //return CalculateAvgCapitalBalance(ref cacheDecimal, ref cacheDate, startRow, endRow);
        //{
        //    throw new NotImplementedException();
        //}


        //private decimal? CalculateAvgCapitalBalance(ref decimal[,] CacheDecimal, ref string[,] CacheDate, int StartRow, int EndRow)

        //{
        //var result = cashFlows.Sum(c => (totalDays - c.datePosition) * c.amount / totalDays);
        //    return result;

        //    //ClientResponse cr = new ClientResponse();
        //    //cr.Payload.Add("balance", result);
        //    //return cr;
        //}
        public ClientResponse insertDateStr(string key, string val)
        {
            throw new NotImplementedException();
        }

        public ClientResponse insertSecurityNo(string key, string val)
        {
            throw new NotImplementedException();
        }

        public ClientResponse insterCostBasis(decimal key, decimal val)
        {
            throw new NotImplementedException();
        }

        public ClientResponse instertMinPk(string key, string val)
        {
            throw new NotImplementedException();
        }

        private decimal? Calculate(ref decimal[,] costBasis, ref string[,] securityNo, ref string[,] dateStr)
        {
            return CalculateAvgCapitalBalance(ref costBasis, ref securityNo, dateStr);
        }

        private decimal? CalculateAvgCapitalBalance(ref decimal[,] costBasis, ref string[,] securityNo, string[,] dateStr)
        {
            throw new NotImplementedException();
        }
    }
}
