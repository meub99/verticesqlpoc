﻿using VerticeSqlPoc.Web.Services.Models;

namespace VerticeSqlPoc.Web.Services.Interfaces
{
    public interface IRedisService
    {
        ClientResponse InsertItem(string key, string val);

        ClientResponse GetItem(string key, string val);
    }
}
