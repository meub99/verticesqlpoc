﻿using VerticeSqlPoc.Web.Services.Models;

namespace VerticeSqlPoc.Web.Services.Interfaces
{
    public interface ISqlService
    {

        ClientResponse FindAll<T>(T arg) where T : class;

    }
}
