﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VerticeSqlPoc.Web.Services.Models;

namespace VerticeSqlPoc.Web.Services.Interfaces
{
    public interface IAvgCapitalBalanceService
    {

        //ClientResponse Calculate(ref decimal[,] cacheDecimal, ref string[,] cacheString, ref string[,] cacheDate, int startRow, int endRow);
        //decimal? Calculate(ref decimal[,] cacheDecimal, ref string[,] cacheString, ref string[,] cacheDate, int startRow, int endRow);

        ClientResponse insterCostBasis(decimal key, decimal val);
        ClientResponse insertSecurityNo(string key, string val);
        ClientResponse insertDateStr(string key, string val);
        ClientResponse instertMinPk(string key, string val);
                      
    }
}