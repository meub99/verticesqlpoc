﻿using Dapper;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using VerticeSqlPoc.Web.Services.Interfaces;
using VerticeSqlPoc.Web.Services.Models;

namespace VerticeSqlPoc.Web.Services
{



    public class SqlService : ISqlService
    {

        #region setup

        private readonly string _connection;
        public SqlService(string connection)
        {
            _connection = connection;
        }

        #endregion

        

        public ClientResponse FindAll<T>(T arg) where T: class
        {

            var _response = new ClientResponse();

            try
            {

                var _query = String.Concat("SELECT TOP 100 * FROM ", arg.GetType().Name.ToLower());
                _response.Payload.Add("Result", JsonConvert.SerializeObject(SelectList<T>(_query)));
                _response.Status = ResponseStatus.Success;


            }
            catch (Exception ex)
            {

                _response.Payload.Add("ErrorMessage", ex.Message);
                _response.Status = ResponseStatus.Error;
                Trace.TraceError(ex.Message);

            }

            return _response;

        }


        List<T> SelectList<T>(string sql, object param = null) where T : class
        {

            using (SqlConnection conn = new SqlConnection(_connection))
            {

                conn.Open();
                return conn.Query<T>(sql, param).ToList();

            }

        }


    }


}
