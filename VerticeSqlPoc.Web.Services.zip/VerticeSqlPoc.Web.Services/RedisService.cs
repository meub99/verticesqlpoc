﻿using StackExchange.Redis;
using System;
using System.Diagnostics;
using VerticeSqlPoc.Web.Services.Interfaces;
using VerticeSqlPoc.Web.Services.Models;

namespace VerticeSqlPoc.Web.Services
{
    public class RedisService : IRedisService
    {

        #region setup
        private static string _connection;
        public RedisService(string connection)
        {
            _connection = connection;
        }
        #endregion

        private static readonly Lazy<ConnectionMultiplexer> _lazyConnection = new Lazy<ConnectionMultiplexer>(() => ConnectionMultiplexer.Connect(_connection));

        private static IDatabase Cache
        {
            get
            {
                return Connection.GetDatabase();
            }
        }

        public static ConnectionMultiplexer Connection
        {
            get
            {
                return _lazyConnection.Value;
            }
        }


        public ClientResponse InsertItem(string key, string value)
        {
            var _response = new ClientResponse();

            try
            {
                Cache.StringSet(key, value);
                _response.Status = ResponseStatus.Success;
            }
            catch (Exception ex)
            {

                _response.Payload.Add("ErrorMessage", ex.Message);
                _response.Status = ResponseStatus.Error;
                Trace.TraceError(ex.Message);

            }

            return _response;

        }

        public ClientResponse GetItem(string key, string value)
        {
            var _response = new ClientResponse();

            try
            {
                _response.Payload.Add("KeyValue", Cache.StringGet(key));
                _response.Status = ResponseStatus.Success;
            }
            catch (Exception ex)
            {

                _response.Payload.Add("ErrorMessage", ex.Message);
                _response.Status = ResponseStatus.Error;
                Trace.TraceError(ex.Message);

            }

            return _response;

        }


    }

}
